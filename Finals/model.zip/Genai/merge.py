from flask import Flask, request, render_template, session
import os
import pandas as pd
from dotenv import load_dotenv
from openai import OpenAI

# Initialize Flask app
app = Flask(__name__)

# Load environment variables from key.env file
load_dotenv(dotenv_path='key.env')

# Initialize OpenAI client with your API key
client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
print("work")

# Load CSV files
df = pd.read_csv('merge.csv').head(100)

# Define routes
@app.route('/', methods=['GET', 'POST'])
def index():
    if 'history' not in session:
        session['history'] = []

    if request.method == 'GET':
        return render_template('test.html', history=session['history'])

    if request.method == 'POST':
        # Get user input from the form
        print("submitted")
        user_input = request.form['user_input']
        print(user_input)
        # Check if user input matches any data in the DataFrame
        matched_data = df[df.isin([user_input]).any(axis=1)]
        
        if not matched_data.empty:
            print("1")
            # If a match is found, return the matched data
            response = matched_data.to_string(index=False)
            print(response)
        else:
            print("2")
            # If no match is found, send user input to OpenAI with the CSV data
            prompt = f"You are a virtual business assistant. Here is the relevant data from the item_info.csv file:\n\n{df.to_string(index=False)}\n\nBased on this data, please answer the following question:\n{user_input}"
            print("3")
            completion = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are a virtual business assistant."},
                    {"role": "user", "content": prompt}
                ]
            )
            print("4")
            # Extract the response text from the completion object
            response = completion.choices[0].message.content
            print(completion.choices[0])
        
        # Update session history
        session['history'].append({'user_input': user_input, 'response': response})
        session.modified = True  # Mark session as modified to ensure it gets saved

        return render_template('test.html', history=session['history'])

# Run Flask app
if __name__ == '__main__':
    app.run(debug=True)
