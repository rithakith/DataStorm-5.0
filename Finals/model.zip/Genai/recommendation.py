from flask import Flask, request, render_template, jsonify
import os
import pandas as pd
from dotenv import load_dotenv
from openai import OpenAI
import sqlite3
from flaskext.markdown import Markdown

# Initialize Flask app
app = Flask(__name__)
Markdown(app)

# Load environment variables from key.env file
load_dotenv(dotenv_path='key.env')

# Initialize OpenAI client with your API key
client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

# Load CSV files
sorted_items_by_name_df = pd.read_csv('sorted_item_names.csv')  # Load sorted_item_names
item_info = pd.read_csv('item_info.csv')
# Define clusters dictionary
clusters = {
    0: {
        "name": "Variety Seekers",
        "description": "This cluster consists of consumers with diverse purchasing patterns. They do not exhibit a preference for any particular category and tend to buy a wide range of products across different departments."
    },
    1: {
        "name": "Pet Enthusiasts",
        "description": "This cluster includes consumers who primarily purchase pet care and pet food products. These shoppers are dedicated pet owners who prioritize the needs of their pets."
    },
    2: {
        "name": "Protein Seekers",
        "description": "This cluster is characterized by consumers who frequently buy seafood and frozen meat. These shoppers are likely to be interested in high-protein diets and may be looking for quality meat and seafood options."
    },
    3: {
        "name": "Fresh Lovers",
        "description": "This cluster includes consumers who predominantly purchase vegetables and fruits. These shoppers prioritize fresh produce and are likely interested in health and nutrition."
    },
    4: {
        "name": "Wellness Seekers",
        "description": "This cluster is made up of consumers who focus on wellness food and wellness products. These shoppers are health-conscious and are looking for products that promote overall well-being."
    }
}

# Define routes
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'GET':
        return render_template('index.html')

    if request.method == 'POST':
        customer_id = request.form['customer_id']
        customer_name = request.form['customer_name']
        requested_output = request.form['requested_output']

        if requested_output == 'Product Recommendations':
            response = product_recommendations(customer_id, customer_name)
            function_name = "Product Recommendations"
        elif requested_output == 'Personalized Shopping List':
            response = personalized_shopping_list(customer_id, customer_name)
            function_name = "Personalized Shopping List"
        else:
            response = tailored_promotions(customer_id, customer_name)
            function_name = "Tailored Promotions"

        return render_template('recommendations.html', recommendations=response, function_name=function_name)

@app.route('/warranty', methods=['GET'])
def warranty():
    return render_template('warranty.html')

@app.route('/check_warranty', methods=['POST'])
def check_warranty():
    customer_id = request.form['customer_id']
    customer_name = request.form['customer_name']

    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT times_visited FROM timesVisited WHERE customer_code = ?", (customer_id,))
    result = c.fetchone()
    conn.close()

    if result and result['times_visited'] > 160:
        response = f"Customer {customer_name} with ID {customer_id} is eligible for warranty."
        message_color = "green"
    elif result:
        response = f"Unfortunately, Customer {customer_name} with ID {customer_id} is not eligible for warranty."
        message_color = "black"
    else:
        response = "Customer not found"
        message_color = "black"

    return render_template('warranty.html', response=response, message_color=message_color)

@app.route('/chatbot')
def chatbot():
    return render_template('chatbot.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get('message')
    print(user_message)

    
    # Check if user is asking about loyalty offer
    if 'loyalty' in user_message.lower() or 'warranty' in user_message.lower():
        # Prompt user for customer code and name
        prompt = "Please go to http://127.0.0.1:5000/check_warranty and provide your customer code and name in our site to check eligibility for our loyalty offer."
        response = generate_openai_response(prompt)
        return jsonify({"response": prompt})
    
     # Check if user is asking about store information
    elif 'store' in user_message.lower() or 'item' in user_message.lower() or 'product' in user_message.lower():
        # Fetch store information from item_info CSV
        store_info = item_info.to_dict(orient='records')
        # You can choose to respond with the first entry from the CSV or a structured response
        prompt = f"You are a virtual business assistant. Here is the relevant data from the item_info.csv file:\n\n{item_info.to_string(index=False)}\n\nBased on this data, please answer the following question:\n{user_message}"
        response = generate_openai_response(prompt)
        return jsonify({"response": response})
    
    else:
        # If not, proceed with regular chatbot functionality
        prompt = f"You are a virtual assistant. The user says: {user_message}"
        response = generate_openai_response(prompt)
        return jsonify({"response": response})

def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

def generate_openai_response(prompt):
    completion = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": "You are a virtual business assistant for our shop KJ Marketing. Your job is to help the users with their queries. start with a greeting and try to personalize with the user"},
            {"role": "user", "content": prompt}
        ]
    )
    response = completion.choices[0].message.content

    # Apply Markdown formatting to the response
    response_with_markdown = f"{response}"

    return response_with_markdown

def product_recommendations(customer_id, customer_name):
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM customerCategoryClusters WHERE customer_code = ?", (customer_id,))
    customer = c.fetchone()
    conn.close()

    if customer:
        customer_category = customer['cluster']  # Assuming the cluster column indicates the customer category
        cluster_info = clusters.get(customer_category, {"name": "Unknown", "description": "No description available."})

        # Generate prompt for OpenAI API
        prompt = f"You are a virtual friendly business marketing assistant. The customer's name is {customer_name}. Here is the relevant data from the sorted_item_names file:\n\n{sorted_items_by_name_df.to_string(index=False)}\n\nBased on this data and the customer's category '{cluster_info['name']}', please provide product recommendations. Suggest the top sales items belonging to that category for the user."

        # Get response from OpenAI API
        recommendations = generate_openai_response(prompt)
    else:
        recommendations = "Customer not found."

    return recommendations

def personalized_shopping_list(customer_id, customer_name):
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT top_5_items FROM topItemsPerCustomer WHERE customer_code = ?", (customer_id,))
    transactions = c.fetchone()

    if transactions:
        top_items = transactions['top_5_items']
        prompt = f"You are a virtual business assistant. The customer's name is {customer_name}.:\n"
        prompt += "\n".join([f"- {item}" for item in top_items])
        prompt += "\n\nPlease prepare a personalized shopping list."

        # Assuming generate_openai_response is a function that sends the prompt to OpenAI API and retrieves the response
        shopping_list = generate_openai_response(prompt)
    else:
        shopping_list = "We couldn't find any purchase history to generate a personalized shopping list."

    conn.close()
    return shopping_list

def tailored_promotions(customer_id, customer_name):
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM customerCategoryClusters WHERE customer_code = ?", (customer_id,))
    customer = c.fetchone()
    conn.close()

    if customer:
        customer_category = customer['cluster']  # Assuming the cluster column indicates the customer category
        cluster_info = clusters.get(customer_category, {"name": "Unknown", "description": "No description available."})

        # Generate prompt for OpenAI API
        prompt = f"You are a virtual business assistant. The customer's name is {customer_name}. Here is the relevant data from the sorted_item_names file:\n\n{sorted_items_by_name_df.to_string(index=False)}\n\nBased on this data and the customer's category '{cluster_info['name']}', please provide tailored promotions."

        # Get response from OpenAI API
        promotions = generate_openai_response(prompt)
    else:
        promotions = "Customer not found."

    return promotions

# Run Flask app
if __name__ == '__main__':
    app.run(debug=True)
