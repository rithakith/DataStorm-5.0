import pandas as pd
import sqlite3

# Step 1: Read the CSV file into a Pandas DataFrame
csv_file_path = 'times_visited.csv'  # Replace with your actual path
df = pd.read_csv(csv_file_path)

# Step 2: Create a SQLite database and connect to it
db_file_path = 'database.db'  # The name of the database file
conn = sqlite3.connect(db_file_path)
c = conn.cursor()

# Step 3: Write the DataFrame to the SQLite database
# We'll use the DataFrame's to_sql method to do this
table_name = 'timesVisited'  # The name of the table to create in the database
df.to_sql(table_name, conn, if_exists='replace', index=False)

# Close the database connection
conn.close()

print(f"CSV data has been successfully written to {db_file_path}")
